package com.alamin.keyboard

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class AlaminImeService : InputMethodService() {
    private var emojiMode = false
    private val categories = listOf(
        "😀" to "😀 😃 😄 😁 😆 😅 😂 🙂 🙃 😉 😊 😍 🥰 😘 😎 🤔 😭 😡",
        "👋" to "👋 🤚 🖐️ ✋ 🖖 👌 🤌 🤏 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 👍 👎",
        "🐶" to "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🐔 🐧",
        "🍎" to "🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🫐 🍈 🍒 🍑 🥭 🍍 🥥 🥝",
        "⚽" to "⚽ 🏀 🏈 ⚾ 🎾 🏐 🏉 🎱 🏓 🏸 🥅 🏒 🏑 🥊",
        "🚗" to "🚗 🚕 🚙 🚌 🚎 🏎️ 🚓 🚑 🚒 🚐 🚚 🚲 ✈️ 🚀 🚁",
        "❤️" to "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗",
        "🇧🇩" to "🇧🇩 🇺🇸 🇬🇧 🇮🇳 🇵🇰 🇯🇵 🇰🇷 🇨🇦 🇦🇺 🇩🇪 🇫🇷 🇧🇷"
    )

    override fun onCreateInputView(): View = buildKeyboard()

    private fun buildKeyboard(): View {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(6, 8, 6, 8)
            setBackgroundColor(Color.rgb(32, 34, 39))
        }
        if (emojiMode) {
            val tabs = LinearLayout(this)
            categories.forEachIndexed { i, pair ->
                tabs.addView(makeButton(pair.first) {
                    showEmojiCategory(panel, i)
                }, LinearLayout.LayoutParams(0, 46, 1f))
            }
            panel.addView(tabs)
            showEmojiCategory(panel, 0)
            panel.addView(makeButton("ABC") { emojiMode = false; setInputView(buildKeyboard()) })
        } else {
            panel.addView(makeButton("😀   Emoji") { emojiMode = true; setInputView(buildKeyboard()) })
            listOf("qwertyuiop", "asdfghjkl", "⇧zxcvbnm⌫").forEach { row ->
                val line = LinearLayout(this)
                row.forEach { ch ->
                    line.addView(makeButton(ch.toString()) { commit(ch.toString()) },
                        LinearLayout.LayoutParams(0, 48, 1f))
                }
                panel.addView(line)
            }
            val bottom = LinearLayout(this)
            listOf("?123", ",", "English / বাংলা", "space", ".", "↵").forEach { key ->
                bottom.addView(makeButton(key) {
                    when (key) {
                        "space" -> commit(" ")
                        "↵" -> currentInputConnection?.performEditorAction(android.view.inputmethod.EditorInfo.IME_ACTION_GO)
                        else -> if (key.length == 1) commit(key)
                    }
                }, LinearLayout.LayoutParams(0, 48, if (key == "space") 3f else 1f))
            }
            panel.addView(bottom)
        }
        return panel
    }

    private fun showEmojiCategory(panel: LinearLayout, index: Int) {
        while (panel.childCount > 1) panel.removeViewAt(1)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        categories[index].second.split(" ").chunked(6).forEach { chunk ->
            val row = LinearLayout(this)
            chunk.forEach { emoji ->
                row.addView(makeButton(emoji) { commit(emoji) },
                    LinearLayout.LayoutParams(0, 48, 1f))
            }
            content.addView(row)
        }
        panel.addView(content, 1)
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 16f
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(55, 59, 67))
        typeface = Typeface.DEFAULT
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun commit(value: String) {
        if (value == "⌫") currentInputConnection?.deleteSurroundingText(1, 0)
        else currentInputConnection?.commitText(value, 1)
    }
}
