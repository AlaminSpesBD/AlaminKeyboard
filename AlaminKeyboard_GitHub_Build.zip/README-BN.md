# Alamin Keyboard — Android ফোন থেকে APK build

## GitHub-এ আপলোড
1. GitHub-এ লগইন করে **New repository** চাপুন।
2. Repository name দিন `AlaminKeyboard`, Public বা Private যেকোনোটি হতে পারে।
3. **Create repository** চাপুন।
4. **Add file → Upload files** নির্বাচন করে এই ZIP-এর ভেতরের সব ফাইল/ফোল্ডার আপলোড করুন (ZIP ফাইলটিকে একা আপলোড করবেন না)।
5. **Commit changes** চাপুন।

## APK তৈরি
- Repository-র **Actions** ট্যাবে যান।
- `Build Alamin Keyboard APK` workflow নির্বাচন করুন।
- **Run workflow** চাপুন (push হলেই workflow স্বয়ংক্রিয়ভাবেও চলবে)।
- সবুজ checkmark এলে workflow run খুলুন।
- নিচের **Artifacts** অংশ থেকে `AlaminKeyboard-debug` ডাউনলোড করুন।
- ZIP extract করে `app-debug.apk` ইনস্টল করুন। Android চাইলে Chrome/Files-কে “Install unknown apps” অনুমতি দিন।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি কেবল একটি প্রাথমিক পরীক্ষামূলক IME skeleton। বাংলা Avro transliteration, Avroid-এর মূল UI/ইঞ্জিন/সেটিংস, পূর্ণ Unicode emoji dataset, emoji search/recent/favorites এখনো যুক্ত নয়। এটি Avroid-এর পরিবর্তিত সংস্করণ নয়। Debug APK ব্যক্তিগত পরীক্ষার জন্য; Play Store release signing করা হয়নি।
